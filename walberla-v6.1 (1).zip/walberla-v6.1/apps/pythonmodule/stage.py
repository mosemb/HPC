if __name__ == "__main__":
    install()  # noqa: F821
