//======================================================================================================================
/*!
 *  \file   CMakeDefs.in.h
 *  \brief  Definitions for blockforest module configured by cmake
 */
//======================================================================================================================

#pragma once

#cmakedefine WALBERLA_BLOCKFOREST_PRIMITIVE_BLOCKID
